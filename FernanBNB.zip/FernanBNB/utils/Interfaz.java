package utils;

import data.AlojamientosCreados;
import model.Alojamiento;
import model.Reserva;
import model.Usuario;
import data.UsuariosCreados;


import java.time.LocalDate;
import java.util.Locale;
import java.util.Scanner;

public class Interfaz { //Este archivo sirve para guardar toda la interfaz del programa (menus principalmente) y pedir información
    static Scanner s = new Scanner(System.in);
    //Metodos
    //Pulsa para continuar
    public static void pulsaParaContinuar(){
        System.out.println("Pulsa cualquier boton para continuar ...");
        s.nextLine();
    }

    //Metodo para crear un usuario
    public static Usuario userAuxiliar(){
        System.out.println("Introduce tu nombre de usuario");
        String nombreUsuario = s.nextLine();
        System.out.println("Introduce tus apellidos");
        String apellidosUsuario = s.nextLine();
        System.out.println("Introduce el tipo de usuario (administrador, propietario, cliente)");
        String tipoUsuario = s.nextLine();
        tipoUsuario = tipoUsuario.toLowerCase(Locale.ROOT);
        System.out.println("Introduce tu correo electronico");
        String emailUsuario = s.nextLine();
        System.out.println("Introduce tu contraseña");
        String contrasenaUsuario = s.nextLine();

        return new Usuario(tipoUsuario, nombreUsuario, apellidosUsuario, contrasenaUsuario, emailUsuario);
    }

    //Menu inicio de sesion
    public static String menuLogin(){
        return """
                FERNAN BNB
                Elige una opción
                1. Crear un nuevo usuario
                2. Iniciar sesion
                3. Usar usuarios de prueba
                4. Ver los usuarios de prueba
                5. Apagar el programa
                """;
    }
    //Interfaz login

    public static String usuarioIntroducido(){
        System.out.println("Introduzca su nombre de usuario o su correo electronico");
        return new String(s.nextLine());
    }
    public static String passwordIntrducida(){
        System.out.println("Introduzca su contraseña");
        return new String(s.nextLine());
    }
    //Menus principales

    //Menu cliente
    public static String menuCliente(){
        return "Bienvenido "+ UsuariosCreados.getUsuarioLogueado().getNombre()+ ", busque un alojamiento para sus próximas vacaciones" + """
                
                Menú principal
                1. Búsqueda de alojamientos
                2. Ver mis reservas
                3. Modificar mis reservas
                4. Ver mi perfil
                5. Modificar mi perfil
                6. Cerrar sesión
                """;
    }

    //Menu propietario
    public static String menuPropietario(){
        return "Bienvenido "+ UsuariosCreados.getUsuarioLogueado().getNombre()+ ", gestione sus viviendas en alquiler" + """
                
                Menú principal
                1. Ver mis viviendas en alquiler
                2. Añadir una vivienda
                3. Editar mis viviendas
                4. Ver las reservas de mis viviendas
                5. Establecer un periodo de no disponible para una vivienda
                6. Ver mi perfil
                7. Modificar mi perfil
                8. Cerrar sesión
                """;
    }

    //Menu administrador
    public static String menuAdmin(){
        return "Bienvenido "+ UsuariosCreados.getUsuarioLogueado().getNombre()+ ", perfil de administración" + """
                
                Menú principal
                1. Ver todas las viviendas en alquiler
                2. Ver todos los usuarios del sistema
                3. Ver todas las reservas de viviendas
                4. Ver mi perfil
                5. Modificar mi perfil
                6. Cerrar sesión
                """;
    }

    //Metodo para crear un alojamiento
    public static Alojamiento alojamientoAux(){
        boolean puede = true;
        switch (UsuariosCreados.getUsuarioLogueado().getId()){
            case 21:
                if (AlojamientosCreados.p1a1Creado) puede = false;
                break;
            case 22:
                if (AlojamientosCreados.p2a1Creado) puede = false;
        }
        if (puede){
            System.out.println("Introduce el nombre del alojamiento");
            String nombre = s.nextLine();
            System.out.println("Introduce la ciudad del alojamiento");
            String ciudad = s.nextLine();
            System.out.println("Introduce la calle del alojamiento");
            String calle = s.nextLine();
            System.out.println("Introduce el numero de huespedes maximos");
            int huespedesMax = Integer.parseInt(s.nextLine());
            System.out.println("Introduce el precio por noche");
            int precioPorNoche = Integer.parseInt(s.nextLine());

            return new Alojamiento(ciudad, calle, nombre, huespedesMax, precioPorNoche);
        }
        else System.out.println("No puedes crear mas usuarios"); return null;
    }
    //Menu de modificación usuario
    public static String menuUsuarioMod(){
        return """
                ¿Que desea modificar?
                1. Nombre
                2. Apellidos
                3. Email
                4. Contraseña
                5. Salir al menu principal
                """;
    }
    //Menu de busqueda de alojamiento
    public static Reserva buscaAlojamiento(){
        String fecha;
        String ciudad;
        int noches;
        int huespedes;

        System.out.println("Introduce la ciudad donde quieres el alojamiento");
        ciudad = s.nextLine();
        ciudad = ciudad.toLowerCase();
        do {
            System.out.println("Introduce la fecha de inicio de la estadia (dd/mm/yyyy)");
            fecha = s.nextLine();
            if (fecha.length() != 10) System.out.println("Introduce datos validos para la fecha");
        } while (fecha.length() != 10);

        int year = Integer.parseInt(fecha.substring(6,10));
        int month = Integer.parseInt(fecha.substring(3,5));
        int day = Integer.parseInt(fecha.substring(0,2));
        LocalDate fechaInicio = LocalDate.of(year, month, day);

        System.out.println("Introduce las noches");
        noches = Integer.parseInt(s.nextLine());

        LocalDate fechaFin = fechaInicio;
        fechaFin = fechaFin.plusDays(noches);

        System.out.println("Introduce los huespedes que van a venir");
        huespedes = Integer.parseInt(s.nextLine());
        return new Reserva(noches, fechaInicio, fechaFin, huespedes, ciudad);
    }
    //Modificar Alojamientos
    public static Alojamiento alojamientoMod(){
        boolean puede = true;
        switch (UsuariosCreados.getUsuarioLogueado().getId()){
            case 21:
                if (!AlojamientosCreados.p1a1Creado) puede = false;
                break;
            case 22:
                if (!AlojamientosCreados.p2a1Creado) puede = false;
        }
        if (puede){
            System.out.println("Introduce el nombre del alojamiento");
            String nombre = s.nextLine();
            System.out.println("Introduce la ciudad del alojamiento");
            String ciudad = s.nextLine();
            System.out.println("Introduce la calle del alojamiento");
            String calle = s.nextLine();
            System.out.println("Introduce el numero de huespedes maximos");
            int huespedesMax = Integer.parseInt(s.nextLine());
            System.out.println("Introduce el precio por noche");
            int precioPorNoche = Integer.parseInt(s.nextLine());

            return new Alojamiento(ciudad, calle, nombre, huespedesMax, precioPorNoche);
        }
        else System.out.println("Primero debes crear un alojamiento"); return null;
    }
    //reserva fecha
    public static Reserva reservaFecha(){
        String fecha;
        int noches = 0;
        do {
            System.out.println("Introduce la fecha de inicio de la estadia (dd/mm/yyyy)");
            fecha = s.nextLine();
            if (fecha.length() != 10) System.out.println("Introduce datos validos para la fecha");
        } while (fecha.length() != 10);

        int year = Integer.parseInt(fecha.substring(6,10));
        int month = Integer.parseInt(fecha.substring(3,5));
        int day = Integer.parseInt(fecha.substring(0,2));
        LocalDate fechaInicio = LocalDate.of(year, month, day);

        System.out.println("Introduce las noches");
        noches = Integer.parseInt(s.nextLine());

        LocalDate fechaFin = fechaInicio;
        fechaFin = fechaFin.plusDays(noches);


        return new Reserva(noches, fechaInicio, fechaFin);
    }
    //modificar reserva
    public static void modificarReserva(Reserva reserva){
        String fecha;
        String ciudad;
        int noches;
        int huespedes;

        System.out.println("Introduce la ciudad donde quieres el alojamiento");
        ciudad = s.nextLine();
        ciudad = ciudad.toLowerCase();
        do {
            System.out.println("Introduce la fecha de inicio de la estadia (dd/mm/yyyy)");
            fecha = s.nextLine();
            if (fecha.length() != 10) System.out.println("Introduce datos validos para la fecha");
        } while (fecha.length() != 10);

        int year = Integer.parseInt(fecha.substring(6,10));
        int month = Integer.parseInt(fecha.substring(3,5));
        int day = Integer.parseInt(fecha.substring(0,2));
        LocalDate fechaInicio = LocalDate.of(year, month, day);

        System.out.println("Introduce las noches");
        noches = Integer.parseInt(s.nextLine());

        LocalDate fechaFin = fechaInicio;
        fechaFin = fechaFin.plusDays(noches);

        System.out.println("Introduce los huespedes que van a venir");
        huespedes = Integer.parseInt(s.nextLine());
        reserva = new Reserva(noches, fechaInicio, fechaFin, huespedes, ciudad);
    }
    public static String usuariosDefault(){
        return "Cliente 1" + "\n" +
                UsuariosCreados.getDc1() + "\n" + "\n" +
                "Cliente 2" + "\n" +
                UsuariosCreados.getDc2() + "\n" + "\n" +
                "Propietario 1" + "\n" +
                UsuariosCreados.getDp1() + "\n" + "\n" +
                "Propietario 2" + "\n" +
                UsuariosCreados.getDp2() + "\n" + "\n" +
                "Administrador" + "\n" +
                UsuariosCreados.getDa1() + "\n"
                ;
    }
}
