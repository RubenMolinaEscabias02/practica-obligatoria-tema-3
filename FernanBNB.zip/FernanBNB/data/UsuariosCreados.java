package data;

import model.Usuario;
import utils.Interfaz;
import java.util.Scanner;

public class UsuariosCreados {
    static Scanner s = new Scanner(System.in);
    static boolean c1Creado = false;
    static boolean c2Creado = false;
    static boolean a1Creado = false;
    static boolean p1Creado = false;
    static boolean p2Creado = false;
    public static boolean logueado = false;
    private static Usuario p1;
    private static Usuario p2;
    private static Usuario a1;
    private static Usuario c1;
    private static Usuario c2;

    private static Usuario usuarioLogueado;

    //Getters y setters

    public static Usuario getP1() {
        return p1;
    }

    public void setP1(Usuario p1) {
        this.p1 = p1;
    }

    public static Usuario getP2() {
        return p2;
    }

    public void setP2(Usuario p2) {
        this.p2 = p2;
    }

    public static Usuario getA1() {
        return a1;
    }

    public void setA1(Usuario a1) {
        this.a1 = a1;
    }

    public static Usuario getC1() {
        return c1;
    }

    public void setC1(Usuario c1) {
        this.c1 = c1;
    }

    public static Usuario getC2() {
        return c2;
    }

    public void setC2(Usuario c2) {
        this.c2 = c2;
    }

    public static Usuario getDc1() {
        return dc1;
    }

    public static Usuario getDc2() {
        return dc2;
    }

    public static Usuario getDp1() {
        return dp1;
    }

    public static Usuario getDp2() {
        return dp2;
    }

    public static Usuario getDa1() {
        return da1;
    }

    public static Usuario getUsuarioLogueado() {
        return usuarioLogueado;
    }

    //Usuarios por defecto
        private static Usuario dc1 = new Usuario("cliente", "pepe", "lendinez", "123", "pepe@gmail.com", 11);
        private static Usuario dc2 = new Usuario("cliente", "antonio", "perez", "123", "antonio@gmail.com", 12);
        private static Usuario dp1 = new Usuario("propietario", "manuel", "molina", "123", "manuel@gmail.com", 21);
        private static Usuario dp2 = new Usuario("propietario", "paco", "garrido", "123", "paco@gmail.com", 22);
        private static Usuario da1 = new Usuario("administrador", "javier", "cuadrado", "123", "javier@gmail.com", 31);

    //Crear usuarios por defecto
    public static void usuariosDefault(){
        c1 = new Usuario(dc1);
        c1Creado = true;
        c2 = new Usuario(dc2);
        c2Creado = true;
        p1 = new Usuario(dp1);
        p1Creado = true;
        p2 = new Usuario(dp2);
        p2Creado = true;
        a1 = new Usuario(da1);
        a1Creado = true;
    }

    //Metodo para asignar el usuario creado antes segun su tipo de cuenta
    public static void asignaUsuario(){
        Usuario usuarioNuevo = new Usuario(Interfaz.userAuxiliar()); //Interfaz visual para crear usuario
        switch (usuarioNuevo.getTipo()){
            case "administrador":

                if (!a1Creado){
                    a1 = new Usuario(usuarioNuevo, 31);
                    a1Creado = true;
                }
                else System.out.println("No hay espacio para mas usuarios administradores");
                break;

            case "propietario":

                if (!p1Creado){
                    p1 = new Usuario(usuarioNuevo, 21);
                    p1Creado = true;
                }
                else if(!p2Creado){
                    p2 = new Usuario(usuarioNuevo, 22);
                    p2Creado = true;
                }
                else System.out.println("No hay espacio para mas usuarios propietarios");
                break;

            case "cliente":
                if (!c1Creado){
                    c1 = new Usuario(usuarioNuevo, 11);
                    c1Creado = true;
                }
                else if(!c2Creado){
                    c2 = new Usuario(usuarioNuevo, 12);
                    c2Creado = true;
                }
                else System.out.println("No hay espacio para mas usuarios cliente");
                break;
        }
    }
    //Login


    public static void login(){
        String usuario = Interfaz.usuarioIntroducido();
        String password = Interfaz.passwordIntrducida();
        if (c1Creado){
            if (usuario.equals(c1.getNombre()) || usuario.equals(c1.getEmail())){
                if (password.equals(c1.getPassword())){
                    usuarioLogueado = new Usuario(c1);
                    logueado = true;
                }
            }
        }
        if (c2Creado){
            if (usuario.equals(c2.getNombre()) || usuario.equals(c2.getEmail())){
                if (password.equals(c2.getPassword())){
                    usuarioLogueado = new Usuario(c2);
                    logueado = true;
                }
            }
        }
        if (p1Creado){
            if (usuario.equals(p1.getNombre()) || usuario.equals(p1.getEmail())){
                if (password.equals(p1.getPassword())){
                    usuarioLogueado = new Usuario(p1);
                    logueado = true;
                }
            }
        }
        if (p2Creado){
            if (usuario.equals(p2.getNombre()) || usuario.equals(p2.getEmail())){
                if (password.equals(p2.getPassword())){
                    usuarioLogueado = new Usuario(p2);
                    logueado = true;
                }
            }
        }
        if (a1Creado){
            if (usuario.equals(a1.getNombre()) || usuario.equals(a1.getEmail())){
                if (password.equals(a1.getPassword())){
                    usuarioLogueado = new Usuario(a1);
                    logueado = true;
                }
            }
        }
        if (!logueado){
            System.out.println("Usuario o contraseña incorrectos");
            Interfaz.pulsaParaContinuar();
        }
    }
    //Modificar usuario
    public static void modificarUsuario(){
        boolean modificando = true;
        do {
            String nombreUsuario = "";
            String apellidosUsuario = "";
            String emailUsuario = "";
            String contrasenaUsuario = "";

            System.out.println(Interfaz.menuUsuarioMod());
            int selector = Integer.parseInt(s.nextLine());
            switch (selector){
                case 1:
                    System.out.println("Introduce tu nuevo nombre de usuario");
                    nombreUsuario = s.nextLine();
                    break;
                case 2:
                    System.out.println("Introduce tus nuevos apellidos");
                    apellidosUsuario = s.nextLine();
                    break;
                case 3:
                    System.out.println("Introduce tu nuevo correo electronico");
                    emailUsuario = s.nextLine();
                    break;
                case 4:
                    System.out.println("Introduce tu nueva contraseña");
                    contrasenaUsuario = s.nextLine();
                    break;
                case 5:
                    modificando = false;
            }
            switch (usuarioLogueado.getId()){
                case 11:
                        switch (selector){
                            case 1:
                                c1.setNombre(nombreUsuario);
                                break;
                            case 2:
                                c1.setApellidos(apellidosUsuario);
                                break;
                            case 3:
                                c1.setEmail(emailUsuario);
                                break;
                            case 4:
                                c1.setPassword(contrasenaUsuario);
                                break;
                        }
                        usuarioLogueado = new Usuario(c1);
                    break;
                case 12:
                    switch (selector){
                        case 1:
                            c2.setNombre(nombreUsuario);
                            break;
                        case 2:
                            c2.setApellidos(apellidosUsuario);
                            break;
                        case 3:
                            c2.setEmail(emailUsuario);
                            break;
                        case 4:
                            c2.setPassword(contrasenaUsuario);
                            break;
                    }
                    usuarioLogueado = new Usuario(c2);
                    break;
                case 21:
                    switch (selector){
                        case 1:
                            p1.setNombre(nombreUsuario);
                            break;
                        case 2:
                            p1.setApellidos(apellidosUsuario);
                            break;
                        case 3:
                            p1.setEmail(emailUsuario);
                            break;
                        case 4:
                            p1.setPassword(contrasenaUsuario);
                            break;
                    }
                    usuarioLogueado = new Usuario(p1);
                    break;
                case 22:
                    switch (selector){
                        case 1:
                            p2.setNombre(nombreUsuario);
                            break;
                        case 2:
                            p2.setApellidos(apellidosUsuario);
                            break;
                        case 3:
                            p2.setEmail(emailUsuario);
                            break;
                        case 4:
                            p2.setPassword(contrasenaUsuario);
                            break;
                    }
                    usuarioLogueado = new Usuario(p2);
                    break;
                case 31:
                    switch (selector){
                        case 1:
                            a1.setNombre(nombreUsuario);
                            break;
                        case 2:
                            a1.setApellidos(apellidosUsuario);
                            break;
                        case 3:
                            a1.setEmail(emailUsuario);
                            break;
                        case 4:
                            a1.setPassword(contrasenaUsuario);
                            break;
                    }
                    usuarioLogueado = new Usuario(a1);
                    break;
            }
        } while (modificando);

    }
    //Mostrar usuario admin
    public static void mostrarUserAdmin(){
        if (c1Creado){
            System.out.println(c1);
            System.out.println("");
        }
        if (c2Creado){
            System.out.println(c2);
            System.out.println("");
        }
        if (p1Creado){
            System.out.println(p1);
            System.out.println("");
        }
        if (p2Creado){
            System.out.println(p2);
            System.out.println("");
        }
    }
}
