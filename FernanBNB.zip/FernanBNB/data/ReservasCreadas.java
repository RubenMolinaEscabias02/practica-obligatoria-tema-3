package data;

import model.Reserva;
import model.Alojamiento;
import utils.Interfaz;

public class ReservasCreadas {
    //Reservas del propietario 1
    public static Reserva r1p1;
    public static Reserva r2p1;
    //Reservas del propietario 2
    public static Reserva r1p2;
    public static Reserva r2p2;

    //Getters

    public static Reserva getR1p1() {
        return r1p1;
    }

    public static Reserva getR2p1() {
        return r2p1;
    }

    public static Reserva getR1p2() {
        return r1p2;
    }

    public static Reserva getR2p2() {
        return r2p2;
    }
    //Crear reserva definitiva
    public static boolean r1p1Creada = false;
    public static boolean r2p1Creada = false;
    public static boolean r1p2Creada = false;
    public static boolean r2p2Creada = false;
    public static void reservaDefinitiva(Alojamiento alojamiento){
        switch (Integer.parseInt(alojamiento.getId().substring(0,2))){
            case 21:
                if (!r1p1Creada){
                    r1p1 = new Reserva(UsuariosCreados.getUsuarioLogueado(), AlojamientosCreados.getP1a1(), AlojamientosCreados.reservaAuxiliar.getFechaEntrada(), AlojamientosCreados.reservaAuxiliar.getFechaSalida(), AlojamientosCreados.reservaAuxiliar.getHuespedes(), AlojamientosCreados.reservaAuxiliar.getNoches());
                    r1p1Creada = true;
                    System.out.println("Su reserva ha sido hecha con exito");
                    System.out.println("");
                    System.out.println(r1p1);
                }else
                if (!r2p1Creada){
                    r2p1 = new Reserva(UsuariosCreados.getUsuarioLogueado(), AlojamientosCreados.getP1a1(), AlojamientosCreados.reservaAuxiliar.getFechaEntrada(), AlojamientosCreados.reservaAuxiliar.getFechaSalida(), AlojamientosCreados.reservaAuxiliar.getHuespedes(), AlojamientosCreados.reservaAuxiliar.getNoches());
                    r2p1Creada = true;
                    System.out.println("Su reserva ha sido hecha con exito");
                    System.out.println("");
                    System.out.println(r2p1);
                }
                break;
            case 22:
                if (!r1p2Creada){
                    r1p2 = new Reserva(UsuariosCreados.getUsuarioLogueado(), AlojamientosCreados.getP2a1(), AlojamientosCreados.reservaAuxiliar.getFechaEntrada(), AlojamientosCreados.reservaAuxiliar.getFechaSalida(), AlojamientosCreados.reservaAuxiliar.getHuespedes(), AlojamientosCreados.reservaAuxiliar.getNoches());
                    r1p2Creada = true;
                    System.out.println("Su reserva ha sido hecha con exito");
                    System.out.println("");
                    System.out.println(r1p2);
                }else
                if (!r2p2Creada){
                    r2p1 = new Reserva(UsuariosCreados.getUsuarioLogueado(), AlojamientosCreados.getP2a1(), AlojamientosCreados.reservaAuxiliar.getFechaEntrada(), AlojamientosCreados.reservaAuxiliar.getFechaSalida(), AlojamientosCreados.reservaAuxiliar.getHuespedes(), AlojamientosCreados.reservaAuxiliar.getNoches());
                    r2p2Creada = true;
                    System.out.println("Su reserva ha sido hecha con exito");
                    System.out.println("");
                    System.out.println(r2p2);
                }

        }
    }
    //Mostrar reservas
    public static void mostrarReservas(){
            if (UsuariosCreados.getUsuarioLogueado().getId() == 11 || UsuariosCreados.getUsuarioLogueado().getId() == 12){
                if (r1p1Creada){
                    if (Integer.parseInt(r1p1.getId().substring(0,2)) == UsuariosCreados.getUsuarioLogueado().getId())
                        System.out.println(r1p1);
                }
                if (r2p1Creada){
                    if (Integer.parseInt(r2p1.getId().substring(0,2)) == UsuariosCreados.getUsuarioLogueado().getId())
                        System.out.println("");
                        System.out.println(r2p1);
                }
                if (r1p2Creada){
                    if (Integer.parseInt(r1p2.getId().substring(0,2)) == UsuariosCreados.getUsuarioLogueado().getId())
                        System.out.println("");
                        System.out.println(r1p2);
                }
                if (r2p2Creada){
                    if (Integer.parseInt(r2p2.getId().substring(0,2)) == UsuariosCreados.getUsuarioLogueado().getId())
                        System.out.println("");
                        System.out.println(r2p2);
                        System.out.println("");
                }
            }
        if (UsuariosCreados.getUsuarioLogueado().getId() == 21){
            if (r1p1Creada){
                System.out.println(r1p1);
                System.out.println("");
            }
            if (r2p1Creada){
                System.out.println(r2p1);
                System.out.println("");
            }
        }
        if( UsuariosCreados.getUsuarioLogueado().getId() == 22){
            if (r1p2Creada){
                System.out.println(r1p2);
                System.out.println("");
            }
            if (r2p2Creada){
                System.out.println(r2p2);
                System.out.println("");
            }
        }
        if (UsuariosCreados.getUsuarioLogueado().getId() == 31){
            if (r1p1Creada){
                System.out.println(r1p1);
                System.out.println("");
            }
            if (r2p1Creada){
                System.out.println(r2p1);
                System.out.println("");
            }
            if (r1p2Creada){
                System.out.println(r1p2);
                System.out.println("");
            }
            if (r2p2Creada){
                System.out.println(r2p2);
                System.out.println("");
            }
        }
        }
        //Reserva fechas
    public static void reservaFechas(){
        Reserva ocupafechas = new Reserva(Interfaz.reservaFecha());
        switch (UsuariosCreados.getUsuarioLogueado().getId()){
            case 21:
                if (AlojamientosCreados.p1a1Creado){
                    if (!r1p1Creada){
                        r1p1 = new Reserva(ocupafechas.getNoches(), ocupafechas.getFechaEntrada(), ocupafechas.getFechaSalida());
                        r1p1Creada = true;
                    }else
                    if (!r2p1Creada){
                        r2p1 = new Reserva(ocupafechas.getNoches(), ocupafechas.getFechaEntrada(), ocupafechas.getFechaSalida());
                        r2p1Creada = true;
                    }
                }
                else System.out.println("No has creado ningun alojamiento");
                break;
            case 22:
                if (AlojamientosCreados.p2a1Creado){
                    if (AlojamientosCreados.p2a1Creado){
                        if (!r1p2Creada){
                            r1p2 = new Reserva(ocupafechas.getNoches(), ocupafechas.getFechaEntrada(), ocupafechas.getFechaSalida());
                            r1p2Creada = true;
                        }else
                        if (!r2p2Creada){
                            r2p2 = new Reserva(ocupafechas.getNoches(), ocupafechas.getFechaEntrada(), ocupafechas.getFechaSalida());
                            r2p2Creada = true;
                        }
                    }
                }
                else System.out.println("No has creado ningun alojamiento");
        }
    }
    }
