package data;

import model.Alojamiento;
import data.ReservasCreadas;
import utils.Interfaz;
import model.Reserva;
import java.util.Scanner;

public class AlojamientosCreados {
    static Scanner s = new Scanner(System.in);
    private static Alojamiento p1a1;
    private static Alojamiento p2a1;
    public static boolean p1a1Creado = false;
    public static boolean p2a1Creado = false;
    //Getter


    public static Alojamiento getP1a1() {
        return p1a1;
    }

    public static Alojamiento getP2a1() {
        return p2a1;
    }

    //Metodos
    //Crear y asignar Alojamientos
    public static void asignaAlojamientos(){
        System.out.println("¿Quieres crear un nuevo alojamiento? (si/no)");
        String respuesta = s.nextLine();
        if (respuesta.equals("si")){
                Alojamiento alojamientoAsignando = new Alojamiento(Interfaz.alojamientoAux());
                switch (UsuariosCreados.getUsuarioLogueado().getId()){
                    case 21:
                        if (UsuariosCreados.p1Creado){
                            p1a1 = new Alojamiento(alojamientoAsignando);
                            p1a1Creado = true;
                        }
                        break;
                    case 22:
                        if (UsuariosCreados.p2Creado){
                            p2a1 = new Alojamiento(alojamientoAsignando);
                            p2a1Creado = true;
                        }
                }
        }
    }
    //Mostrar alojamientos
    public static void muestraAlojamientos(){
        if (UsuariosCreados.p1Creado){
            if (UsuariosCreados.getUsuarioLogueado().getId() == UsuariosCreados.getP1().getId()){
                if (p1a1Creado) System.out.println(p1a1);
            }
        }
        if (UsuariosCreados.p2Creado){
            if (UsuariosCreados.getUsuarioLogueado().getId() == UsuariosCreados.getP2().getId()){
                if (p2a1Creado) System.out.println(p2a1);
            }
        }
        if (UsuariosCreados.a1Creado){
            if (UsuariosCreados.getUsuarioLogueado().getId() == UsuariosCreados.getA1().getId()){
                if (p1a1Creado) System.out.println(p1a1);
                if (p2a1Creado) System.out.println(p2a1);
                if (!p1a1Creado && !p2a1Creado) System.out.println("No hay ninguna vivienda creada");
            }
        }
    }
    //Filtrar alojamientos
    public static boolean encontrado = false;
    public static boolean encontrado1 = false;
    public static boolean encontrado2 = false;

    public  static Reserva reservaAuxiliar;
    public static void filtraAlojamientos(){
        reservaAuxiliar = new Reserva(Interfaz.buscaAlojamiento());
        if (p1a1Creado) {
            if (reservaAuxiliar.getCiudad().equals(p1a1.getCiudad()) && reservaAuxiliar.getHuespedes() < p1a1.getHuespedesMax()){
                System.out.println("Se han encontrado estos alojamientos para ti");
                System.out.println("");
                System.out.println(p1a1);
                encontrado = true;
                encontrado1 = true;
            }
        }
        if (p2a1Creado){
            if (reservaAuxiliar.getCiudad().equals(p2a1.getCiudad()) && reservaAuxiliar.getHuespedes() < p2a1.getHuespedesMax()){
                if (!encontrado) System.out.println("Se han encontrado estos alojamientos para ti"); encontrado = true;
                System.out.println("");
                System.out.println(p2a1);
                encontrado2 = true;
            }
        }
        if (!encontrado) System.out.println("No se ha encontrado ningun alojamiento para ti");
    }

    //Modificar alojamientos
    public static void modificaAlojamientos() {
        Alojamiento alojamientoAsignando = new Alojamiento(Interfaz.alojamientoMod());
        switch (UsuariosCreados.getUsuarioLogueado().getId()) {
            case 21:
                if (UsuariosCreados.p1Creado) {
                    p1a1 = new Alojamiento(alojamientoAsignando);
                    p1a1Creado = true;
                }
                break;
            case 22:
                if (UsuariosCreados.p2Creado) {
                    p2a1 = new Alojamiento(alojamientoAsignando);
                    p2a1Creado = true;
                }
        }
    }
}
