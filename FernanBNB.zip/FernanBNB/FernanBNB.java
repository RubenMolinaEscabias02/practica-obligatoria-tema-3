import data.AlojamientosCreados;
import data.ReservasCreadas;
import model.Reserva;
import model.Usuario;
import utils.Interfaz;

import java.util.Scanner;
import data.UsuariosCreados;

public class FernanBNB {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean encendido = true;

        do{
            //Menu login (solo aparece si no estas logueado
            if (!UsuariosCreados.logueado){
                System.out.println(Interfaz.menuLogin());
                int selector = Integer.parseInt(s.nextLine());
                switch (selector){
                    case 1:
                        UsuariosCreados.asignaUsuario();
                        break;
                    case 2:
                        UsuariosCreados.login();
                        break;
                    case 3:
                        UsuariosCreados.usuariosDefault();
                        System.out.println("Se han activado los datos de usuarios de prueba");
                        Interfaz.pulsaParaContinuar();
                        break;
                    case 4:
                        System.out.println(Interfaz.usuariosDefault());
                        Interfaz.pulsaParaContinuar();
                        break;
                    case 5:
                        encendido = false;
                        System.out.println("Gracias por usar nuestros servicios");
                    case 6:
                        System.out.println(UsuariosCreados.getC1());
                }
            }
            //Menu principal
            else{
                switch (UsuariosCreados.getUsuarioLogueado().getTipo()){
                    case "cliente":
                        System.out.println(Interfaz.menuCliente());
                        int selectorc = Integer.parseInt(s.nextLine());
                        switch (selectorc){
                            case 1:
                                System.out.println("¿Quieres hacer la reserva?");
                                System.out.println("1. Si");
                                System.out.println("2. No");
                                int respuesta = Integer.parseInt(s.nextLine());
                                if (respuesta == 1){
                                AlojamientosCreados.filtraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                if (AlojamientosCreados.encontrado){
                                    boolean salir = false;
                                    do {
                                        if (AlojamientosCreados.encontrado1 && !AlojamientosCreados.encontrado2){
                                            System.out.println("¿Quieres hacer la reserva?");
                                            System.out.println("1. Si");
                                            System.out.println("2. No");
                                            int respuesta2 = Integer.parseInt(s.nextLine());
                                            if (respuesta2 == 1){
                                                if (ReservasCreadas.r1p1Creada && ReservasCreadas.r2p1Creada) System.out.println("Esta vivienda no acepta mas reservas"); salir = true;
                                                if (ReservasCreadas.r1p1Creada){
                                                    if ((AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isAfter(ReservasCreadas.r1p1.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isBefore(ReservasCreadas.r1p1.getFechaSalida())) || ((AlojamientosCreados.reservaAuxiliar.getFechaSalida().isAfter(ReservasCreadas.r1p1.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaSalida().isBefore(ReservasCreadas.r1p1.getFechaSalida()))) || AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isEqual(ReservasCreadas.r1p1.getFechaEntrada()) || AlojamientosCreados.reservaAuxiliar.getFechaSalida().isEqual(ReservasCreadas.r1p1.getFechaSalida())){
                                                        System.out.println("Fecha no disponible");
                                                    }
                                                    else ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1()); salir = true;
                                                }
                                                if (!ReservasCreadas.r1p1Creada){
                                                    ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1()); salir = true;
                                                }
                                            }
                                            if (respuesta2 == 2) salir = true;
                                        }

                                        if (AlojamientosCreados.encontrado2 && !AlojamientosCreados.encontrado1){
                                            System.out.println("¿Quieres hacer la reserva?");
                                            System.out.println("1. Si");
                                            System.out.println("2. No");
                                            int respuesta2 = Integer.parseInt(s.nextLine());
                                            if (respuesta2 == 1){
                                                if (ReservasCreadas.r1p2Creada && ReservasCreadas.r2p2Creada) System.out.println("Esta vivienda no acepta mas reservas"); salir = true;
                                                if (ReservasCreadas.r1p2Creada){
                                                    if ((AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isAfter(ReservasCreadas.r1p2.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isBefore(ReservasCreadas.r1p2.getFechaSalida())) || ((AlojamientosCreados.reservaAuxiliar.getFechaSalida().isAfter(ReservasCreadas.r1p2.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaSalida().isBefore(ReservasCreadas.r1p2.getFechaSalida()))) || AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isEqual(ReservasCreadas.r1p2.getFechaEntrada()) || AlojamientosCreados.reservaAuxiliar.getFechaSalida().isEqual(ReservasCreadas.r1p2.getFechaSalida())){
                                                        System.out.println("Fecha no disponible");
                                                    }
                                                    else ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1()); salir = true;
                                                }
                                                if (!ReservasCreadas.r1p2Creada){
                                                    ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1()); salir = true;
                                                }
                                            }
                                            if (respuesta2 == 2) salir = true;
                                        }

                                        if (AlojamientosCreados.encontrado2 && AlojamientosCreados.encontrado1){
                                            System.out.println("Elige entre los dos alojamientos");
                                            System.out.println("1. " + AlojamientosCreados.getP1a1().getNombre());
                                            System.out.println("2. " + AlojamientosCreados.getP2a1().getNombre());
                                            System.out.println("3. Salir");
                                            int opt = Integer.parseInt(s.nextLine());
                                            switch (opt){
                                                case 1:
                                                    if (ReservasCreadas.r1p1Creada){
                                                        if ((AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isAfter(ReservasCreadas.r1p1.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isBefore(ReservasCreadas.r1p1.getFechaSalida())) || ((AlojamientosCreados.reservaAuxiliar.getFechaSalida().isAfter(ReservasCreadas.r1p1.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaSalida().isBefore(ReservasCreadas.r1p1.getFechaSalida()))) || AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isEqual(ReservasCreadas.r1p1.getFechaEntrada()) || AlojamientosCreados.reservaAuxiliar.getFechaSalida().isEqual(ReservasCreadas.r1p1.getFechaSalida())){
                                                            System.out.println("Esta fecha esta ocupada");
                                                        }
                                                        else ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1());
                                                    }
                                                    if (!ReservasCreadas.r1p1Creada){
                                                        ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1());
                                                    }
                                                    if (ReservasCreadas.r1p1Creada && ReservasCreadas.r2p1Creada) System.out.println("Esta vivienda no acepta mas reservas");
                                                    break;
                                                case 2:
                                                    if (ReservasCreadas.r1p2Creada){
                                                        if ((AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isAfter(ReservasCreadas.r1p2.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isBefore(ReservasCreadas.r1p2.getFechaSalida())) || ((AlojamientosCreados.reservaAuxiliar.getFechaSalida().isAfter(ReservasCreadas.r1p2.getFechaEntrada()) && AlojamientosCreados.reservaAuxiliar.getFechaSalida().isBefore(ReservasCreadas.r1p2.getFechaSalida()))) || AlojamientosCreados.reservaAuxiliar.getFechaEntrada().isEqual(ReservasCreadas.r1p2.getFechaEntrada()) || AlojamientosCreados.reservaAuxiliar.getFechaSalida().isEqual(ReservasCreadas.r1p2.getFechaSalida())){
                                                            System.out.println("Esta fecha esta ocupada");
                                                        }
                                                        else ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1());
                                                    }
                                                    if (!ReservasCreadas.r1p2Creada){
                                                        ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1());
                                                    }
                                                    if (ReservasCreadas.r1p2Creada && ReservasCreadas.r2p2Creada) System.out.println("Esta vivienda no acepta mas reservas");
                                                    break;
                                                case 3:
                                                    salir = true;
                                            }

                                        }
                                    }while (!salir);
                                }}
                                break;
                            case 2:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 3:
                                ReservasCreadas.mostrarReservas();
                                System.out.println("");
                                System.out.println("Selecciona cual quieres modificar");
                                int optr = Integer.parseInt(s.nextLine());
                                switch (optr){
                                    case 1:
                                        if (ReservasCreadas.r1p1Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR1p1());
                                        }
                                        break;
                                    case 2:
                                        if (ReservasCreadas.r2p1Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR2p1());
                                        }
                                        break;
                                    case 3:
                                        if (ReservasCreadas.r1p2Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR1p2());
                                        }
                                        break;
                                    case 4:
                                        if (ReservasCreadas.r2p2Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR2p2());
                                        }
                                }
                                break;
                            case 4:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 6:
                                UsuariosCreados.logueado = false;
                                break;
                        }
                        break;
                    case "propietario":
                        System.out.println(Interfaz.menuPropietario());
                        int selectorp = Integer.parseInt(s.nextLine());
                        switch (selectorp){
                            case 1:
                                AlojamientosCreados.muestraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 2:
                                AlojamientosCreados.asignaAlojamientos();
                                break;
                            case 3:
                                AlojamientosCreados.modificaAlojamientos();
                                break;
                            case 4:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                ReservasCreadas.reservaFechas();
                                break;
                            case 6:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 7:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 8:
                                UsuariosCreados.logueado = false;
                                break;
                        }
                        break;
                    case "administrador":
                        System.out.println(Interfaz.menuAdmin());
                        int selectora = Integer.parseInt(s.nextLine());
                        switch (selectora){
                            case 1:
                                AlojamientosCreados.muestraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 2:
                                UsuariosCreados.mostrarUserAdmin();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 3:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 4:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 6:
                                UsuariosCreados.logueado = false;
                                break;
                        }
                }
            }

        }while(encendido);
    }
}