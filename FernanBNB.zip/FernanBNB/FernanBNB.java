import data.AlojamientosCreados;
import data.ReservasCreadas;
import model.Reserva;
import model.Usuario;
import utils.Interfaz;

import java.util.Scanner;
import data.UsuariosCreados;

public class FernanBNB {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean encendido = true;

        do{
            //Menu login (solo aparece si no estas logueado
            if (!UsuariosCreados.logueado){
                System.out.println(Interfaz.menuLogin());
                int selector = Integer.parseInt(s.nextLine());
                switch (selector){
                    case 1:
                        UsuariosCreados.asignaUsuario();
                        break;
                    case 2:
                        UsuariosCreados.login();
                        break;
                    case 3:
                        encendido = false;
                        System.out.println("Gracias por usar nuestros servicios");
                }
            }
            //Menu principal
            else{
                switch (UsuariosCreados.getUsuarioLogueado().getTipo()){
                    case "cliente":
                        System.out.println(Interfaz.menuCliente());
                        int selectorc = Integer.parseInt(s.nextLine());
                        switch (selectorc){
                            case 1:
                                AlojamientosCreados.filtraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                if (AlojamientosCreados.encontrado){
                                    if (AlojamientosCreados.encontrado1)ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1());
                                    if (AlojamientosCreados.encontrado2)ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1());
                                    if (AlojamientosCreados.encontrado2 && AlojamientosCreados.encontrado1){
                                        System.out.println("Elige entre los dos alojamientos");
                                        System.out.println("1. " + AlojamientosCreados.getP1a1().getNombre());
                                        System.out.println("2. " + AlojamientosCreados.getP2a1().getNombre());
                                        int opt = Integer.parseInt(s.nextLine());
                                        switch (opt){
                                            case 1:
                                                ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP1a1());
                                                break;
                                            case 2:
                                                ReservasCreadas.reservaDefinitiva(AlojamientosCreados.getP2a1());
                                        }
                                    }
                                }
                                break;
                            case 2:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 3:
                                ReservasCreadas.mostrarReservas();
                                System.out.println("");
                                System.out.println("Selecciona cual quieres modificar");
                                int optr = Integer.parseInt(s.nextLine());
                                switch (optr){
                                    case 1:
                                        if (ReservasCreadas.r1p1Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR1p1());
                                        }
                                        break;
                                    case 2:
                                        if (ReservasCreadas.r2p1Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR2p1());
                                        }
                                        break;
                                    case 3:
                                        if (ReservasCreadas.r1p2Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR1p2());
                                        }
                                        break;
                                    case 4:
                                        if (ReservasCreadas.r2p2Creada){
                                            Interfaz.modificarReserva(ReservasCreadas.getR2p2());
                                        }
                                }
                                break;
                            case 4:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 6:
                                UsuariosCreados.logueado = false;
                        }
                        break;
                    case "propietario":
                        System.out.println(Interfaz.menuPropietario());
                        int selectorp = Integer.parseInt(s.nextLine());
                        switch (selectorp){
                            case 1:
                                AlojamientosCreados.muestraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 2:
                                AlojamientosCreados.asignaAlojamientos();
                                break;
                            case 3:
                                AlojamientosCreados.modificaAlojamientos();
                                break;
                            case 4:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                ReservasCreadas.reservaFechas();
                                break;
                            case 6:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 7:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 8:
                                UsuariosCreados.logueado = false;
                        }
                        break;
                    case "administrador":
                        System.out.println(Interfaz.menuAdmin());
                        int selectora = Integer.parseInt(s.nextLine());
                        switch (selectora){
                            case 1:
                                AlojamientosCreados.muestraAlojamientos();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 2:
                                UsuariosCreados.mostrarUserAdmin();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 3:
                                ReservasCreadas.mostrarReservas();
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 4:
                                System.out.println(UsuariosCreados.getUsuarioLogueado());
                                Interfaz.pulsaParaContinuar();
                                break;
                            case 5:
                                UsuariosCreados.modificarUsuario();
                                break;
                            case 6:
                                UsuariosCreados.logueado = false;
                        }
                }
            }

        }while(encendido);
    }
}