package model;

public class Usuario {
    //Atributos
    private String tipo;
    private String nombre;
    private String apellidos;
    private String password;
    private String email;
    private int id;

    //Constructor


    public Usuario(String tipo, String nombre, String apellidos, String password, String email) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.password = password;
        this.email = email;
    }
    //Constructor copia

    public Usuario(Usuario usuario) {
        this.tipo = usuario.tipo;
        this.nombre = usuario.nombre;
        this.apellidos = usuario.apellidos;
        this.password = usuario.password;
        this.email = usuario.email;
        this.id = usuario.id;
    }
    //Constructor default

    public Usuario() {

    }
    //constructor id

    public Usuario(Usuario usuario, int id) {
        this.tipo = usuario.tipo;
        this.nombre = usuario.nombre;
        this.apellidos = usuario.apellidos;
        this.password = usuario.password;
        this.email = usuario.email;
        this.id = id;
    }

    //Constructor para usuarios default
    public Usuario(String tipo, String nombre, String apellidos, String password, String email, int id) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.password = password;
        this.email = email;
        this.id = id;
    }

    //Getters y setters

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }
    //ToString

    @Override
    public String toString() {
        return  "===Usuario con ID: " + id+ "===" + "\n" +
                "Nombre del usuario: " + nombre + "\n" +
                "Apellidos: " + apellidos + "\n" +
                "Email: " + email + "\n" +
                "Contraseña " + password;
    }
}
