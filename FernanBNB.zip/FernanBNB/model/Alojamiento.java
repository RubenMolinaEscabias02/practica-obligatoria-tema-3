package model;

import data.UsuariosCreados;

public class Alojamiento {
    //Atributos
    private String ciudad;
    private String calle;
    private String nombre;
    private int huespedesMax;
    private int precioPorNoche;
    private String fechasNoDisponible;
    private String id;

    //Constructor

    public Alojamiento(String ciudad, String calle, String nombre, int huespedesMax, int precioPorNoche) {
        this.ciudad = ciudad;
        this.calle = calle;
        this.nombre = nombre;
        this.huespedesMax = huespedesMax;
        this.precioPorNoche = precioPorNoche;
        this.id = Integer.toString(UsuariosCreados.getUsuarioLogueado().getId()) + Integer.toString(precioPorNoche);
    }
    //Constructor copia

    public Alojamiento(Alojamiento alojamiento) {
        this.ciudad = alojamiento.ciudad;
        this.calle = alojamiento.calle;
        this.nombre = alojamiento.nombre;
        this.huespedesMax = alojamiento.huespedesMax;
        this.precioPorNoche = alojamiento.precioPorNoche;
        this.id = alojamiento.id;
    }
    //Constructor teclado

    //Getters

    public String getCiudad() {
        return ciudad;
    }

    public String getCalle() {
        return calle;
    }

    public String getNombre() {
        return nombre;
    }

    public int getHuespedesMax() {
        return huespedesMax;
    }

    public int getPrecioPorNoche() {
        return precioPorNoche;
    }

    public String getFechasNoDisponible() {
        return fechasNoDisponible;
    }

    public String getId() {
        return id;
    }

    //ToString

    @Override
    public String toString() {
        return
               "===Alojamiento con ID: " + id+ "===" + "\n" +
                "Nombre del alojamiento: " + nombre + "\n" +
                       "Dirección: " + calle + ", " + ciudad + "\n" +
                       "Numero de huespedes máximo: " + huespedesMax + "\n" +
                       "Precio por noche: " + precioPorNoche + "€"
                ;
    }
}

