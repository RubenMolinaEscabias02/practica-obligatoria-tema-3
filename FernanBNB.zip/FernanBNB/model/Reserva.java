package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.MonthDay;
import java.util.Calendar;

public class Reserva {
    private String id;
    private String nombreUsuario;
    private String nombreAlojamiento;
    private int noches;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;
    private int huespedes;
    private int precioPorNoche;
    private int precioTotal;
    private String ciudad;
    private int idUsuario;

    //constructor

    public Reserva(Usuario usuario, Alojamiento alojamiento, LocalDate fechaEntrada, LocalDate fechaSalida, int huespedes, int noches) {
        this.id = Integer.toString(usuario.getId()) + alojamiento.getId();
        this.nombreUsuario = usuario.getNombre();
        this.nombreAlojamiento = alojamiento.getNombre();
        this.noches = noches;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.huespedes = huespedes;
        this.precioPorNoche = alojamiento.getPrecioPorNoche();
        this.precioTotal = alojamiento.getPrecioPorNoche() * noches;
        this.idUsuario = usuario.getId();
    }
    //Constructor teclado

    public Reserva(int noches, LocalDate fechaEntrada, LocalDate fechaSalida, int huespedes, String ciudad) {
        this.noches = noches;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.huespedes = huespedes;
        this.ciudad = ciudad;
    }
    //Constructor copia

    public Reserva(Reserva reserva) {
        this.id = reserva.id;
        this.nombreUsuario = reserva.nombreUsuario;
        this.nombreAlojamiento = reserva.nombreAlojamiento;
        this.noches = reserva.noches;
        this.fechaEntrada = reserva.fechaEntrada;
        this.fechaSalida = reserva.fechaSalida;
        this.huespedes = reserva.huespedes;
        this.precioPorNoche = reserva.precioPorNoche;
        this.precioTotal = reserva.precioTotal;
        this.ciudad = reserva.ciudad;
        this.idUsuario = reserva.idUsuario;
    }
    //Constructor fecha

    public Reserva(int noches, LocalDate fechaEntrada, LocalDate fechaSalida) {
        this.noches = noches;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
    }


    //getters y setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getNombreAlojamiento() {
        return nombreAlojamiento;
    }

    public void setNombreAlojamiento(String nombreAlojamiento) {
        this.nombreAlojamiento = nombreAlojamiento;
    }

    public int getNoches() {
        return noches;
    }

    public void setNoches(int noches) {
        this.noches = noches;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }


    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public int getHuespedes() {
        return huespedes;
    }

    public void setHuespedes(int huespedes) {
        this.huespedes = huespedes;
    }

    public int getPrecioPorNoche() {
        return precioPorNoche;
    }

    public void setPrecioPorNoche(int precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    public int getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(int precioTotal) {
        this.precioTotal = precioTotal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    //ToString

    @Override
    public String toString() {
            return  "===Reserva con ID: " + id+ "===" + "\n" +
                    "Nombre del usuario: " + nombreUsuario + "\n" +
                    "Alojamiento: " + nombreAlojamiento + "\n" +
                    "Noches: " + noches + "\n" +
                    "Entrada: " + fechaEntrada + "\n" +
                    "Salida: " + fechaSalida + "\n" +
                    "Huespedes: " + huespedes + "\n" +
                    "Precio por noche: " + precioPorNoche + "€, " + "Precio total: " + precioTotal + "€"
                    ;
        }
}
